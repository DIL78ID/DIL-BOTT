const help = (prefix, pushname) => {
	return `✪═⟪ DILBOT BOT MENU ⟫═✪

*AUTHOR : FADIL*
*BOT TYPE : TERMUX*

╔════════════════════
║ Hai Kak *${pushname}*
╠════════════════════
║╭──❉ *INFO* ❉──
║┣➥ *${prefix}info*
║┣➥ *${prefix}bugreport* [lapor bug]
║┣➥ *${prefix}runtime*
║┣➥ *${prefix}join* [linkgroup]
║╰───────────
║╭──❉ *GROUP MENU* ❉──
║┣➥ *${prefix}clone*
║┣➥ *${prefix}promote* [tag]
║┣➥ *${prefix}demote* [tag]
║┣➥ *${prefix}tagall* [1 atau 2 atau 3]
║┣➥ *${prefix}simih* [0 atau 1]
║┣➥ *${prefix}group* [open atau close]
║┣➥ *${prefix}setdesc* [teks]
║┣➥ *${prefix}setpp* 
║┣➥ *${prefix}setname* [teks]
║┣➥ *${prefix}kick* [tag]
║┣➥ *${prefix}linkgroup*
║╰───────────
║╭──❉ *MEDIA* ❉──
║┣➥ *${prefix}toimg*
║┣➥ *${prefix}sticker*
║┣➥ *${prefix}ttp* [teks]
║┣➥ *${prefix}sticker nobg* [ERROR]
║┣➥ *${prefix}tts* [kode bahasa] [teks]
║┣➥ *${prefix}url2img* [tipe] [url]
║┣➥ *${prefix}wait* 
║┣➥ *${prefix}ocr*
║┣➥ *${prefix}nulis* [teks]
║╰───────────
║╭──❉ *OWNER MENU* ❉──
║┣➥ *${prefix}setprefix* [prefix]
║┣➥ *${prefix}bc* [promosi]
║┣➥ *${prefix}setppbot* 
║┣➥ *${prefix}clone* [tag]
║╰───────────
║╭──❉ *IKLAN* ❉──
║┣➥ *Instagram*
║│ *fadil_vg78*
║┣➥ *Creator DILBOT*
║│ *https://wa.me/6285343788098*
║╰───────────
║╭──❉ *PERATURAN* ❉──
║┣➥ *JANGAN NELPON*
║┣➥ *JANGAN SPAM*
║╰───────────
╠════════════════════
║  *POWERED BY FADIL*
╚════════════════════`
}

exports.help = help
